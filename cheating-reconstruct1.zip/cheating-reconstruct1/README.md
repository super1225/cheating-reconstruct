# cheating-detection
Paper: Few-shot Learning for Trajectory-based Mobile Game Cheating Detection

Dependencies  
The code is written in Python 3 with Pytorch 1.6.0.

Results
![Result](https://github.com/super1225/cheating-detection/blob/32d71319a34885a9e37d9b75a69a5d809805c3c5/result.png)

Dataset  
Due to the privacy of dataset, we have published ten samples for analysis in .
